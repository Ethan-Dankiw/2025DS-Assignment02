package net.ethandankiw.data.http;

public enum HttpRequestMethod {
	NONE,
	GET,
	PUT
}