package net.ethandankiw.server;

public interface ServerBalancer {

	void balanceServers();
}
